﻿using System;
using System.Collections.Generic;

class SayaTubeUser
{
    private int id;
    private List<SayaTubeVideo> uploadedVideos;
    public string Username { get; private set; }

    public SayaTubeUser(string username)
    {
        if (string.IsNullOrEmpty(username) || username.Length > 100)
            throw new ArgumentException("Username tidak boleh null dan maksimal 100 karakter.");

        Random rand = new Random();
        this.id = rand.Next(10000, 99999); // ID random 5 digit
        this.Username = username;
        this.uploadedVideos = new List<SayaTubeVideo>();
    }

    public void AddVideo(SayaTubeVideo video)
    {
        if (video == null)
            throw new ArgumentNullException("Video yang ditambahkan tidak boleh null.");

        if (video.GetPlayCount() >= int.MaxValue)
            throw new OverflowException("Play count video melebihi batas integer.");

        uploadedVideos.Add(video);
    }

    public int GetTotalVideoPlayCount()
    {
        int total = 0;
        foreach (var video in uploadedVideos)
        {
            total += video.GetPlayCount();
        }
        return total;
    }

    public void PrintAllVideoPlaycount()
    {
        Console.WriteLine($"User: {Username}");
        for (int i = 0; i < uploadedVideos.Count && i < 8; i++) // Maksimal cetak 8 video
        {
            Console.WriteLine($"Video {i + 1} judul: {uploadedVideos[i].GetTitle()}");
        }
        Console.WriteLine($"\nTotal play count: {GetTotalVideoPlayCount()}");
    }
}
