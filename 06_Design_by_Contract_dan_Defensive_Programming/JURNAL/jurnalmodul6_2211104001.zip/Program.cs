﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        try
        {
            SayaTubeUser user = new SayaTubeUser("Devrin Anggun");

            List<string> videoTitles = new List<string>
            {
                "Review Film Pengabdi Setan 3 oleh Devrin Anggun",
                "Review Film KKN di Desa Penari 2 oleh Devrin Anggun",
                "Review Film Sewu Dino 2 oleh Devrin Anggun",
                "Review Film Ratu Pantai Selatan oleh Devrin Anggun",
                "Review Film Hantu Pohon Beringin oleh Devrin Anggun",
                "Review Film Teror Gunung Kawi oleh Devrin Anggun",
                "Review Film Malam Satu Suro Reborn oleh Devrin Anggun",
                "Review Film Rumah Kentang: The Curse oleh Devrin Anggun",
                "Review Film Jurnal Risa: Teror Rumah Kosong oleh Devrin Anggun",
                "Review Film Hantu Kuburan Belanda oleh Devrin Anggun"
            };

            foreach (var title in videoTitles)
            {
                SayaTubeVideo video = new SayaTubeVideo(title);
                user.AddVideo(video);
                video.IncreasePlayCount(1000000); // Tambah 1 juta views tiap video
            }

            user.PrintAllVideoPlaycount();

            // Simulasi error play count
            try
            {
                SayaTubeVideo testVideo = new SayaTubeVideo("Test Video Error");
                testVideo.IncreasePlayCount(30000000); // Melebihi batas 25 juta
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }

            // Simulasi error input null
            try
            {
                SayaTubeVideo videoError = new SayaTubeVideo(null);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }

            try
            {
                user.AddVideo(null);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
    }
}
